<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<html>
<head>
  <title></title>
  <link rel="stylesheet" href="./css/style.css">
</head>
<body>
<div id="wrap">
  <header>
    <jsp:include page="./menu.jsp"/>
  </header>

<article>
  <table class="table">
    <tr>
      <th>제품번호</th>
      <th>이미지</th>
      <th>제품명</th>
      <th>제품가격</th>
      <th>비고</th>
    </tr>

    <tr align="center">
      <td></td>
      <td><img src="images/" width="100" height="95"></td>
      <td>
        <a href="product_content.jsp?prod_num=">

        </a>
      </td>
      <td>
        할인가 : 원<br>
        <font color="red">()</font>
      </td>
      <td>
        시중 가격 : 원
      </td>
    </tr>

  </table>











</article>
</div>
</body>
</html>